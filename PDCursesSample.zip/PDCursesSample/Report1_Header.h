#pragma once

#define BUFFSIZE 128

struct Day {
	int id;
	int date[3];
	double max_temp;
	double min_temp;
	Day* next_day;
};

struct Days {
	int id;
	Day* first_day;
};

double calc_mean_temp(int sid, int eid, Days days);

int get_id(int year, int month, int day, Days days);


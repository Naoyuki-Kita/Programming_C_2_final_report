#pragma once

#define BUFFSIZE 128

struct MyDay {
	int id;
	int date[3];
	double daily_mean_temp;
	MyDay* next_day;
};

struct MyMonth {
	int id;
	int date[2];
	int days_num;
	double monthly_mean_temp;
	MyDay* first_day;
	MyMonth* next_month;
};

struct MyYear {
	int id;
	int date[1];
	MyMonth* first_month;
	MyYear* next_year;
};

struct MyYears {
	int id;
	MyYear* first_year;
};

MyMonth* get_my_month(MyYears years, int date[]);




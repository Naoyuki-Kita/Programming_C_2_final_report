#include "Header.h"

MyMonth* get_my_month(MyYears years, int date[]) {
	int year_num = date[0];
	int month_num = date[1];

	MyYear* year = years.first_year;
	while (year->date[0] != date[0]) {
		year = year->next_year;
	}

	MyMonth* month = year->first_month;
	while (month->date[1] != date[1]) {
		month = month->next_month;
	}

	return month;
}


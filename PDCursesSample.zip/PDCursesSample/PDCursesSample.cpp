﻿// PDCursesSample.cpp : このファイルには 'main' 関数が含まれています。プログラム実行の開始と終了がそこで行われます。

#include <stdio.h>
#include <curses.h>
#include <iostream>
#include "functions.cpp"

#define BUFFSIZE 128

int main() {
	FILE* fp;					//csvファイル格納用のファイル型構造体
	char s[BUFFSIZE];			//csvファイルから読み取った文字列を格納する配列
	char buff[BUFFSIZE];		//文字出力用の配列
	char delim[] = "/, ";		//文字列分割に用いるデリミタ
	char* ctx;
	char* p1;					//分割後の文字列の一時的な格納場所
	double mean_temps[12] = {};	//月ごとの平均気温を格納する配列
	int days_num[12] = {};		//月ごとの日数を格納する配列
	double mean_temp;			//平均気温を格納する変数
	int year_num;				//日付(年)を格納する変数
	int month_num;				//日付(月)を格納する変数
	int day_num;				//日付(日)を格納する変数
	int days_cnt;				//月ごとの日数をカウントする変数
	int max_y;					//グラフ描画の際y軸の長さを決めるための変数
	MyDay* previous_day = NULL;	//単方向リスト実装のための前の要素を保管するポインタ
	MyMonth* previous_month = NULL;	//同上
	MyYear* previous_year = NULL;		//同上
	MyYears years;

	//カレントディレクトリに存在するcsvファイルを開く
	errno_t error;
	error = fopen_s(&fp, "data.csv", "r");

	if (error != 0) {	//失敗した場合エラーメッセージを表示し終了
		fprintf_s(stderr, "failed to open");
		return -1;
	}
	else {				//成功した場合データを読み込む
		for (int i = 0; fgets(s, BUFFSIZE, fp) != NULL; i++) {	//1行ずつ読み込み
			if (i < 5) continue;				//1～5行目はヘッダなので無視
			//行をデリミタ("/"と","と" ")を用いて分割
			p1 = strtok_s(s, delim, &ctx);		//1つ目は年(2011～2020)なのでyear_numに格納
			year_num = atoi(p1);				//int型にキャスト

			p1 = strtok_s(NULL, delim, &ctx);	//2つ目は月(1～12)なのでmonth_numに格納
			month_num = atoi(p1);				//int型にキャスト

			p1 = strtok_s(NULL, delim, &ctx);	//3つ目は日(1～31)なのでday_numに格納
			day_num = atoi(p1);

			p1 = strtok_s(NULL, delim, &ctx);	//4つ目は平均気温なのでmean_tempに格納
			mean_temp = atof(p1);				//double型にキャスト

			//それ以降は品質情報、均質番号なので無視
			//データの取得完了

			//構造体MyDay型の一時的な変数tmp_dayを初期化し、データを代入していく
			MyDay* tmp_day = new MyDay();
			tmp_day->id = i - 5;				//最初のデータは6行目(i == 5)なので調整
			tmp_day->date[0] = year_num;
			tmp_day->date[1] = month_num;
			tmp_day->date[2] = day_num;			//それぞれ日付を代入
			tmp_day->daily_mean_temp = mean_temp;	//日ごとの平均気温を代入
			tmp_day->next_day = NULL;			//次のDayは存在しているか不明なのでNULL

			//previous_dayに対する処理
			if (previous_day != NULL) {
				previous_day->next_day = tmp_day;	//次のDayを指定
			}
			previous_day = tmp_day;					//previous_dayの更新

			if (day_num == 1) {
				//day_num == 1、つまり月初めの場合
				//構造体Month型の一時的な変数tmp_monthを初期化し、同様にデータを代入する
				MyMonth* tmp_month = new MyMonth();
				
				tmp_month->date[0] = year_num;
				tmp_month->date[1] = month_num;
				tmp_month->days_num = 1;
				tmp_month->monthly_mean_temp = 0.0;
				tmp_month->first_day = tmp_day;
				tmp_month->next_month = NULL;

				if (previous_month == NULL) {
					//NULLの場合前月のデータがないので前月に対する処理を行わない
					//先頭なのでidは0にする
					tmp_month->id = 0;
				}
				else {
					//NULLでない場合前月に対する処理を行う
					tmp_month->id = previous_month->id + 1;
					previous_month->days_num = days_cnt;
					//previous_monthの平均気温monthly_mean_tempを計算する
					MyDay* day = previous_month->first_day;	//最初のday
					double sum_temp = 0.0;					//合計値を格納する変数
					while (day->date[1] == previous_month->date[1]) {			
						sum_temp += day->daily_mean_temp;
						day = day->next_day;
					}
					//合計値から平均値を算出し格納
					previous_month->monthly_mean_temp = sum_temp / previous_month->days_num;
					//previous_monthのnext_monthを指定
					previous_month->next_month = tmp_month;
				}
				//previous_monthの更新
				previous_month = tmp_month;

				if (month_num == 1) {
					//年初めの場合
					//構造体Year型の一時的な変数tmp_yearを初期化し、同様にデータを代入する
					MyYear* tmp_year = new MyYear();
					tmp_year->date[0] = year_num;
					tmp_year->first_month = tmp_month;
					tmp_year->next_year = NULL;
					if (previous_year == NULL) {
						//NULLの場合前年のデータがないので前年に対する処理を行わない
						//先頭なのでidは0になる
						tmp_year->id = 0;
					}
					else {
						//NULLでない場合前年に対する処理を行う
						tmp_year->id = previous_year->id + 1;
						//previous_yearのnext_yearを指定
						previous_year->next_year = tmp_year;
					}
					//previous_yearの更新
					previous_year = tmp_year;

					if (year_num == 2011) {
						//year_num == 2011、つまり最初のデータの場合
						//Years型構造体yearsの初期化
						years.id = 0;
						years.first_year = tmp_year;
					}
				}
				//日数のリセット
				days_cnt = 1;
			}
			else {
				//月初めでない場合、日数を+1
				days_cnt++;
			}
		}
		fclose(fp);			//ファイルを閉じる
		//データ格納完了

		//=========================================================-ここから書き直す

		//制御端末を開始
		if (initscr() == NULL) { //開始に失敗した場合終了
			return -1;
		}

		int year = 2011;
		int month = 1;
		int day = 1;
		start_color();
		//選択されていない状態の色
		init_pair(1, COLOR_WHITE, COLOR_BLACK);
		//選択されている状態の色
		init_pair(2, COLOR_RED, COLOR_BLACK);
		bkgd(COLOR_PAIR(1));

		//グラフを描画するため、y軸の長さを決める
		int max_y = 0;		//y座標の最大値=y軸の長さ
		//mean_tempsの中の最大値をint型にキャストし、max_yに代入
		for (int i = 0; i < 12; i++) {
			if (max_y < mean_temps[i]) {
				//round(double x)…引数のdouble型変数を四捨五入しdouble型変数として返却する
				max_y = (int)(round(mean_temps[i]));
			}
		}
		//そのままだと縦に長くなりすぎたので、1/2に縮小
		max_y = (int)(round(max_y / 2));
		//5を足して余裕を持たせる
		max_y += 5;

		//無限ループ内に処理を書かないと表示されないため、whileループを用いる
		while (true) {
			// 画面をクリア
			erase();
			// 文字列を描く
			mvaddstr(0, 0, "京田辺の平均気温");		//タイトル
			sprintf_s(buff, "%d/%d", year, month);
			mvaddstr(1, 0, buff);	//年/月の表示
			int date[] = { year, month };
			MyMonth* current_month = get_my_month(years, date);	//表示する月の取得
			MyDay* current_day = current_month->first_day;	//表示する日の取得
			
			//表の表示
			//表示する月の全ての日の平均気温を表示
			//ただし、int型変数dayで指定されている日は赤文字で表示
			//ついでにmax_y(yの最大値)を求める
			for (int i = 1; current_day != NULL; i++) {
				if (i == day) {
					attrset(COLOR_PAIR(2));	//赤文字
				}
				else {
					attrset(COLOR_PAIR(1));	//白文字(default)
				}
				sprintf_s(buff, "\t%d\t%lfdo", current_day->date[2], current_day->daily_mean_temp);
				mvaddstr(i + 1, 0, buff);	//"	(日数)	(平均気温)"の形で表示
				if (max_y < current_day->daily_mean_temp) {
					max_y = (int)(round(current_day->daily_mean_temp));
				}
				current_day = current_day->next_day;
			}

			//無限ループから抜ける用のキー入力を受け付ける
			//'q'でbreakする
			mvaddstr(35, 0, "press q to exit\n");
			int key = getch();
			if (key == 'q') break;

			// 画面を更新
			refresh();
		}
		//制御端末の終了
		endwin();

	}
	return 0;
}
